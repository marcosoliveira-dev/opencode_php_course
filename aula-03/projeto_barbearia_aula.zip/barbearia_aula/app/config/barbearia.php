<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "app/database/barbearia.db",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];
