<?php
/**
 * SystemUser REST service
 */
class RecordServiceExample extends AdiantiRecordService
{
    const DATABASE      = 'database-name';
    const ACTIVE_RECORD = 'Model';
    const ATTRIBUTES    = ['id', 'name', '...'];
    const REST_KEY      = 'your-rest-key';
}
